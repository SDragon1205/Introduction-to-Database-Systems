Chungcheongnam-do	20
Incheon	19
Ulsan	13
