Belgium Jupiler League	0.3914
England Premier League	0.3725
France Ligue 1	0.3635
Germany 1. Bundesliga	0.3812
Italy Serie A	0.3727
Netherlands Eredivisie	0.3861
Poland Ekstraklasa	0.3821
Portugal Liga ZON Sagres	0.3971
Scotland Premier League	0.3871
Spain LIGA BBVA	0.3904
Switzerland Super League	0.3895
