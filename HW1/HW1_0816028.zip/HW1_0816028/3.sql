Gyeongsangnam-do	Changwon-si	110
Gyeonggi-do	Yongin-si	103
Gyeonggi-do	Suwon-si	99
