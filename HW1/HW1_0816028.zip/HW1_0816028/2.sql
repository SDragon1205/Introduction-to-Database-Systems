contact with patient
overseas inflow
Shincheonji Church
