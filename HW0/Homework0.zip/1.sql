SELECT count(*) cnt
FROM search_trend
WHERE cold > 0.2;