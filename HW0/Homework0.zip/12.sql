SELECT id, date, overall_rating
FROM player_attributes
ORDER BY id ASC, date asc;
